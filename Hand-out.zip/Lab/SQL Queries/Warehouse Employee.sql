/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [timestamp]
      ,[User ID]
      ,[Location Code]
      ,[Default]
      ,[ADCS User]
  FROM [CRONUS].[dbo].[CRONUS International Ltd_$Warehouse Employee$437dbf0e-84ff-417a-965d-ed2bb9650972]
  with(readuncommitted)
  where [Location Code] like 'GU%'