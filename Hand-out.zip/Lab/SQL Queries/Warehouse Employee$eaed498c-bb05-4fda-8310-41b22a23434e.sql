/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [timestamp]
      ,[User ID]
      ,[Location Code]
      ,[Allowed to Delete Shpt_ Line]
  FROM [CRONUS].[dbo].[CRONUS International Ltd_$Warehouse Employee$eaed498c-bb05-4fda-8310-41b22a23434e]
  with(readuncommitted)