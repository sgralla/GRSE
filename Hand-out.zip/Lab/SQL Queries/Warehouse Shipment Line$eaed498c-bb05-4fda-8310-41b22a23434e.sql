/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [timestamp]
      ,[No_]
      ,[Line No_]
      ,[System-Created]
  FROM [CRONUS].[dbo].[CRONUS International Ltd_$Warehouse Shipment Line$eaed498c-bb05-4fda-8310-41b22a23434e]
  with(readuncommitted)